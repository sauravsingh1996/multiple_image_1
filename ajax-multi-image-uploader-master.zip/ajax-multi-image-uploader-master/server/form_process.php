<?php

/*
 * Ajax Multiple Image Uploader
 * https://github.com/tharindulucky/ajax-multi-image-uploader
 *
 * Copyright 2018, Tharindu Lakshitha
 * https://coderaweso.me
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 *
 * Use this file for stuff like DB operations
 *
 */

if(isset($_POST['submit'])){
    die(var_dump($_POST['uploaded_image_name']));
    //Save to DB
    //Do whatever you want

}